# ChemCalc 1.0 - Free bilingual chemistry calculator
# Requires Python + Kivy. For Android, try Pydroid 3 with Kivy support.
from collections import defaultdict
import re
from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.scrollview import ScrollView
from kivy.core.window import Window

ATOMIC_MASS = {
    'H':1.008,'He':4.0026,'Li':6.94,'Be':9.0122,'B':10.81,'C':12.011,'N':14.007,'O':15.999,'F':18.998,'Ne':20.180,
    'Na':22.990,'Mg':24.305,'Al':26.982,'Si':28.085,'P':30.974,'S':32.06,'Cl':35.45,'Ar':39.948,'K':39.098,'Ca':40.078,
    'Sc':44.956,'Ti':47.867,'V':50.942,'Cr':51.996,'Mn':54.938,'Fe':55.845,'Co':58.933,'Ni':58.693,'Cu':63.546,'Zn':65.38,
    'Br':79.904,'Ag':107.868,'I':126.904,'Ba':137.327,'Hg':200.592,'Pb':207.2
}

def molar_mass(formula):
    formula = formula.strip().replace(' ', '')
    if not formula: raise ValueError('Enter a chemical formula.')
    tokens = re.findall(r'[A-Z][a-z]?|\d+|[()]', formula)
    if ''.join(tokens) != formula: raise ValueError('Unsupported formula characters.')
    i = 0
    def group(nested=False):
        nonlocal i
        counts = defaultdict(int)
        while i < len(tokens):
            t = tokens[i]
            if t == ')':
                if not nested: raise ValueError('Unexpected closing parenthesis.')
                i += 1
                return counts
            if t == '(':
                i += 1
                inner = group(True)
                multiplier = 1
                if i < len(tokens) and tokens[i].isdigit():
                    multiplier = int(tokens[i]); i += 1
                for el, n in inner.items(): counts[el] += n * multiplier
            elif t.isdigit(): raise ValueError('A number must follow an element or group.')
            else:
                if t not in ATOMIC_MASS: raise ValueError(f'Unknown element: {t}')
                i += 1
                n = 1
                if i < len(tokens) and tokens[i].isdigit(): n = int(tokens[i]); i += 1
                counts[t] += n
        if nested: raise ValueError('Missing closing parenthesis.')
        return counts
    counts = group()
    if i != len(tokens): raise ValueError('Could not parse formula.')
    return sum(ATOMIC_MASS[e]*n for e,n in counts.items()), dict(counts)

def calculate_molarity(mass_g, molar_mass_g_mol, volume_l):
    if mass_g < 0 or molar_mass_g_mol <= 0 or volume_l <= 0:
        raise ValueError('Mass cannot be negative; molar mass and volume must be positive.')
    return (mass_g / molar_mass_g_mol) / volume_l

def calculate_dilution(c1, c2, v2):
    if c1 <= 0 or c2 < 0 or v2 <= 0: raise ValueError('C1 and final volume must be positive; C2 cannot be negative.')
    if c2 > c1: raise ValueError('Target concentration cannot exceed stock concentration for dilution.')
    v1 = c2*v2/c1
    return v1, v2-v1

class ChemCalcRoot(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', padding=dp(12), spacing=dp(8), **kwargs)
        self.lang='ar'; self.current_tool='molarity'; self.field_inputs={}
        Window.clearcolor=(0.055,0.075,0.11,1)
        header=BoxLayout(size_hint_y=None,height=dp(48),spacing=dp(8))
        self.title_label=Label(text='ChemCalc',bold=True,font_size='24sp',color=(0.35,0.85,0.75,1))
        self.lang_button=Button(text='English',size_hint_x=None,width=dp(100)); self.lang_button.bind(on_press=self.toggle_language)
        header.add_widget(self.title_label); header.add_widget(self.lang_button); self.add_widget(header)
        self.subtitle=Label(text='',size_hint_y=None,height=dp(30),color=(0.85,0.9,0.95,1)); self.add_widget(self.subtitle)
        self.tool_picker=Spinner(text='المولارية',values=('المولارية','التخفيف','الكتلة المولية'),size_hint_y=None,height=dp(46))
        self.tool_picker.bind(text=self.on_tool_change); self.add_widget(self.tool_picker)
        self.scroll=ScrollView(); self.fields_box=GridLayout(cols=1,spacing=dp(8),size_hint_y=None,padding=(0,dp(4)))
        self.fields_box.bind(minimum_height=self.fields_box.setter('height')); self.scroll.add_widget(self.fields_box); self.add_widget(self.scroll)
        self.result_label=Label(text='',size_hint_y=None,height=dp(76),color=(0.45,0.95,0.65,1),halign='left',valign='middle')
        self.result_label.bind(size=lambda inst,val:setattr(inst,'text_size',val)); self.add_widget(self.result_label)
        self.calculate_button=Button(text='',size_hint_y=None,height=dp(48),background_color=(0.12,0.55,0.48,1))
        self.calculate_button.bind(on_press=self.calculate); self.add_widget(self.calculate_button)
        self.rebuild_fields(); self.update_language()
    def toggle_language(self,*_):
        self.lang='en' if self.lang=='ar' else 'ar'; self.update_language(); self.rebuild_fields()
    def on_tool_change(self,spinner,text):
        mapping={'المولارية':'molarity','التخفيف':'dilution','الكتلة المولية':'mass','Molarity':'molarity','Dilution':'dilution','Molar mass':'mass'}
        self.current_tool=mapping.get(text,'molarity'); self.rebuild_fields(); self.result_label.text=''
    def update_language(self):
        ar=self.lang=='ar'; self.lang_button.text='English' if ar else 'العربية'
        self.subtitle.text='حاسبة كيميائية مجانية' if ar else 'Free chemistry calculator'
        self.calculate_button.text='احسب' if ar else 'Calculate'
        self.tool_picker.values=('المولارية','التخفيف','الكتلة المولية') if ar else ('Molarity','Dilution','Molar mass')
        self.tool_picker.text={'molarity':'المولارية' if ar else 'Molarity','dilution':'التخفيف' if ar else 'Dilution','mass':'الكتلة المولية' if ar else 'Molar mass'}[self.current_tool]
    def rebuild_fields(self):
        self.fields_box.clear_widgets(); self.field_inputs={}; ar=self.lang=='ar'
        if self.current_tool=='molarity': specs=[('mass','كتلة المذاب (g)' if ar else 'Solute mass (g)','5.85'),('mm','الكتلة المولية (g/mol)' if ar else 'Molar mass (g/mol)','58.44'),('vol','حجم المحلول (L)' if ar else 'Solution volume (L)','0.5')]
        elif self.current_tool=='dilution': specs=[('c1','تركيز المحلول الأصلي C1' if ar else 'Stock concentration C1','1.0'),('c2','التركيز المطلوب C2' if ar else 'Target concentration C2','0.1'),('v2','الحجم النهائي V2 (L)' if ar else 'Final volume V2 (L)','0.25')]
        else: specs=[('formula','الصيغة الكيميائية' if ar else 'Chemical formula','Ca(OH)2')]
        for key,caption,default in specs:
            lab=Label(text=caption,size_hint_y=None,height=dp(28),halign='left',color=(0.92,0.94,0.97,1))
            lab.bind(size=lambda inst,val:setattr(inst,'text_size',val)); self.fields_box.add_widget(lab)
            inp=TextInput(text=default,multiline=False,size_hint_y=None,height=dp(46),font_size='18sp',padding=(dp(10),dp(10)))
            self.field_inputs[key]=inp; self.fields_box.add_widget(inp)
    def number(self,key):
        value=float(self.field_inputs[key].text.strip())
        if value != value or abs(value)==float('inf'): raise ValueError('Please enter a finite number.')
        return value
    def calculate(self,*_):
        ar=self.lang=='ar'
        try:
            if self.current_tool=='molarity':
                result=calculate_molarity(self.number('mass'),self.number('mm'),self.number('vol'))
                self.result_label.text=f'التركيز = {result:.6g} mol/L' if ar else f'Molarity = {result:.6g} mol/L'
            elif self.current_tool=='dilution':
                v1,solvent=calculate_dilution(self.number('c1'),self.number('c2'),self.number('v2'))
                self.result_label.text=(f'حجم الأصلي = {v1:.6g} L\nالمذيب تقريباً = {solvent:.6g} L' if ar else f'Stock volume = {v1:.6g} L\nApprox. solvent = {solvent:.6g} L')
            else:
                mm,counts=molar_mass(self.field_inputs['formula'].text); breakdown=' + '.join(f'{el}×{n}' for el,n in counts.items())
                self.result_label.text=(f'الكتلة المولية = {mm:.4f} g/mol\n{breakdown}' if ar else f'Molar mass = {mm:.4f} g/mol\n{breakdown}')
        except Exception as exc: self.result_label.text=('خطأ: ' if ar else 'Error: ')+str(exc)

class ChemCalcApp(App):
    title='ChemCalc'
    def build(self): return ChemCalcRoot()

if __name__=='__main__': ChemCalcApp().run()
