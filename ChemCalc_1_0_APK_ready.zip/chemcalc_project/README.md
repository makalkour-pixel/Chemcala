# ChemCalc 1.0

Free bilingual (Arabic/English) chemistry calculator built with Python + Kivy.

## Current features
- Molarity from solute mass, molar mass and solution volume
- Dilution using C1*V1 = C2*V2
- Molar mass for common elements and formulas with parentheses

## Android testing
1. Install Pydroid 3 from its official store listing.
2. Install/enable Kivy support for Pydroid 3 if required by your installation.
3. Save/open `main.py` on your phone in Pydroid 3 and run it.
4. Try the examples below.

APK packaging is a separate step. Running Python in Pydroid does not automatically create a standalone APK. A reproducible APK build generally needs a supported Buildozer/Linux build environment.

## Expected test examples
- H2SO4 molar mass ≈ 98.072 g/mol
- Ca(OH)2 molar mass ≈ 74.092 g/mol
- 5.844 g NaCl (58.44 g/mol) in 1 L gives 0.100 mol/L
- Dilute 1.0 mol/L stock to 0.1 mol/L, final volume 0.25 L: use 0.025 L stock, then bring the solution to a final volume of 0.25 L.

Note: The solvent volume displayed by the app is an approximation because solution volumes are not always additive. For accurate preparation, dissolve the solute and bring the solution to the specified final volume in suitable volumetric glassware. Independently verify results before laboratory use.
