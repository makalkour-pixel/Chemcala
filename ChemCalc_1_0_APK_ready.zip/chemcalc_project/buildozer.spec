[app]
title = ChemCalc
package.name = chemcalc
package.domain = org.chemcalc
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf,otf
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0

# Android settings
android.minapi = 23
android.api = 35
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
